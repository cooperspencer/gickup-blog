---
Title: Source
weight: 12
---

Gickup supports various code hosters:
- [Github](https://github.com/)
- [Gitea](https://gitea.io/en-us/)
- [Gogs](https://gogs.io/)
- [Gitlab](https://about.gitlab.com/)
- [Onedev](https://code.onedev.io/)
- [Sourcehut](https://sourcehut.org/)

But you can also backup every repository that is not hosted on any of those hosters whith the `Any` key.

{{< button "./github/" "Github" >}}