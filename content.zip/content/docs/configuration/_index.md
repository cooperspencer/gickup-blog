---
Title: Configuration
weight: 11
---

It shows how to configure gickup to clone your repositories
1. [Source](./source/)
2. [Destination](./destination/)
3. [Miscellaneous](./miscellaneous/)

{{< button "./source/" "Configure source" >}}
