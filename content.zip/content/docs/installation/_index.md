---
Title: Installation
weight: 1
---

You can get gickup on various ways:
1. Binary
2. Docker
3. Compile it yourself

{{< button "./installation/" "Methods to install" >}}
