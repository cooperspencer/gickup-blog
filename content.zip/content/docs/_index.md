---
title: "Getting started"
weight: 1
---

These docs consists the following parts:

1. [Installation](./installation/)
2. [Configuration](./configuration/)

{{< button "./installation/" "Installation" "mb-1" >}}

